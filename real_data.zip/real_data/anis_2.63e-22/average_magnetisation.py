import numpy as np
import math


#W0[i,0]->temp
#W0[i,1]->seed
#W0[i,2]-> k0
#W0[i,3]->damp



def func():
		#add here starting and ending point 
    for temp in (0.1, 200.1, 400.1, 500.1, 550.1, 600.1, 620.1, 640.1, 660.1, 680.1):
        mx[:]=0.0
        my[:]=0.0
        mz[:]=0.0
        time[:]=0.0
        temp1[:]=0.0
        count[:]=0
        for seed in (1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20):
            f_read=open("Temp_"+str(temp)+"/random_"+str(seed)+"/output")
            Wr= np.loadtxt(f_read)
            n=np.shape(Wr)
            for i in range(0,n[0]):
                 count[i]=count[i]+1
                 time[i]=time[i]+Wr[i,0]
                 temp1[i]=temp1[i]+Wr[i,1]
                 mx[i]=mx[i]+Wr[i,2]
                 my[i]=my[i]+Wr[i,3]
                 mz[i]=mz[i]+Wr[i,4]
                 
        f_out=open("output_av_temp"+str(temp),'w+')		     
        for i in range(0,n[0]):	    
             print(time[i]/count[i], temp1[i]/count[i],mx[i]/count[i],my[i]/count[i],mz[i]/count[i], file=f_out)
 
         
       

n=3000
mx=np.empty(n)
my=np.empty(n)
mz=np.empty(n)
time=np.empty(n)
count=np.empty(n)
temp1=np.empty(n)
func()





