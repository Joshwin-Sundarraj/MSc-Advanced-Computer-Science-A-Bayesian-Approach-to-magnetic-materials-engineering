import numpy as np
import math


#W0[i,0]->time
#W0[i,2]->mx
#W0[i,3]->my
#W0[i,4]->mz
#W0[i,5]->m


def calc_chi(p1,p2,count):
      chi_x=0.0
      chi_y=0.0
      chi_z=0.0
      
      filename='/users/mss555/scratch/grid_search/single_spin_reference_nofield_30_new/'+'Anis_'+str(p1)+'e-22Damp_'+str(p2)+'/output' 
      W0= np.loadtxt(filename)
      for i in range(0,2999):
          chi_x=chi_x+(W0[i,2]-Wc[i,2])**2
          chi_y=chi_y+(W0[i,3]-Wc[i,3])**2
          chi_z=chi_z+(W0[i,4]-Wc[i,4])**2
          
      chi_all=chi_x+chi_y+chi_z   
      #print count, p1, p2, chi_x, chi_y, chi_z, chi_all
      print(count, p1 , p2, chi_x, chi_y, chi_z, chi_all, file=f1)
      
      #store in an array
      chi_array[count]=chi_all
      param_array[count][0]=p1
      param_array[count][1]=p2
      
      


      
def findMinIndex(array, start_index):
    min_value = array[start_index]
    min_index = start_index
    #print 'min', min_value, min_index
    for index in range(start_index, len(array)):
       
    	if array[index] < min_value:
        	min_value = array[index]
        	min_index = index
    return min_index


#temp_test , seed = input('input temperature  ')
#print 'temp, and seed',temp_test, seed


#temp_test =format(temp_test, '.1f')


#print 'input parameters are', p1_f_test, p2_f_test

#file_comp='/home/mara/programs/grid_search_method/data_yarcc_grains/Relax_10nm_5nm_diff_seed/Temp_'+str(temp_test)+'size_5seed_'+ str(seed)+ '/output'
 
#print 'analysing data at temp', temp_test, 'from file ', file_comp
file_comp='input_grid_search'

Wc= np.loadtxt(file_comp)
f1=open("res_grid",'w+')
f2=open("out_final",'w+')
n=np.shape(Wc)

anis_step=0.060
anis_start=0.000
anis_end=2.700
Damp_step=0.01
Damp_start=0.010
Damp_end=0.100


Hk=np.arange(anis_start, anis_end, anis_step)
Damp=np.arange(Damp_start, Damp_end, Damp_step)



p1_size=np.shape(Hk)
p2_size=np.shape(Damp)

all_size=p1_size[0]*p2_size[0]
chi_array=np.empty(all_size)
param_array=np.empty(shape=[all_size, 2])

print('Starting calculations first search..............')

#print  p1_size
#print p2_size
count=0
for i in range(0,p1_size[0]):
    print('Anis=', Hk[i])
    for j in range(0,p2_size[0]):
        anis=Hk[i]
        damp=Damp[j]
        anis=format(anis, '.3f')
        damp=format(damp, '.3f')
        #print anis, damp
        calc_chi(anis,damp,count)
        count=count+1
        

min_index=findMinIndex(chi_array,0)

anis_start=param_array[min_index,0]-anis_step
anis_end=param_array[min_index,0]+anis_step
anis_step=0.015



Hk=np.arange(anis_start, anis_end, anis_step)
Damp=np.arange(Damp_start, Damp_end, Damp_step)



p1_size=np.shape(Hk)
p2_size=np.shape(Damp)

all_size=p1_size[0]*p2_size[0]
chi_array=np.empty(all_size)
param_array=np.empty(shape=[all_size, 2])

print('Starting calculations second search anisotropy..............')

#print  p1_size
#print p2_size
count=0
for i in range(0,p1_size[0]):
    print('Anis=', Hk[i])
    for j in range(0,p2_size[0]):
        anis=Hk[i]
        damp=Damp[j]
        anis=format(anis, '.3f')
        damp=format(damp, '.3f')
        #print anis, damp
        calc_chi(anis,damp,count)
        count=count+1
        

min_index=findMinIndex(chi_array,0)

print('anisotropy is ', param_array[min_index,0])

print('Starting calculations search damping..............')


anis=param_array[min_index,0]
anis=format(anis, '.3f')
Damp_step=0.001
Damp_end=0.200
Damp=np.arange(Damp_start, Damp_end, Damp_step)

p2_size=np.shape(Damp)

all_size=p2_size[0]
chi_array=np.empty(all_size)
param_array=np.empty(shape=[all_size, 2])



#print  p1_size
#print p2_size
count=0

for j in range(0,p2_size[0]):
        
        damp=Damp[j]
        damp=format(damp, '.3f')
        #print anis, damp
        calc_chi(anis,damp,count)
        count=count+1
        

min_index=findMinIndex(chi_array,0)
print('final results: ', param_array[min_index,0], param_array[min_index,1])
print(param_array[min_index,0],param_array[min_index,1], file=f2)
#print>> param_array[min_index,0],param_array[min_index,1]
